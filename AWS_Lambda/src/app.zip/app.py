def handler(event, context):
    return {
        "statusCode": 200,
        "body": "hey sucessfully created the infra, its just the beginning lot to come"
    }